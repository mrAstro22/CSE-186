/*
#######################################################################
#
# Copyright (C) 2020-2026 David C. Harrison. All right reserved.
#
# You may not use, distribute, publish, or modify this code without
# the express written permission of the copyright holder.
#
#######################################################################
*/
import express from 'express';
import yaml from 'js-yaml';
import swaggerUi from 'swagger-ui-express';
import fs from 'fs';
import path from 'node:path';
import OpenApiValidator from 'express-openapi-validator';
import {fileURLToPath} from 'node:url';
import * as mail from './router/route.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());
app.use(express.urlencoded({extended: false}));

const apiSpec = path.join(__dirname, '../api/openapi.yaml');

const apidoc = yaml.load(fs.readFileSync(apiSpec, 'utf8'));
app.use('/api/v0/docs', swaggerUi.serve, swaggerUi.setup(apidoc));

app.use(
    OpenApiValidator.middleware({
      apiSpec: apiSpec,
      validateRequests: true,
      validateResponses: true,
    }),
);


// Your routes go here; however, do NOT write then inline.
// Create route handler modules in the "route" foleder and delegate
// to their exports. Those handlers should delegate to models in
// the "model" folder.

// Get All Mail/Mailbox
app.get('/api/v0/mail', mail.getAll);

// GET email by ID
app.get('/api/v0/mail/:id', mail.getByID);

// GET From Sender
app.get('/api/v0/mail/from/:from', mail.getFrom);

// POST new Email
app.post('/api/v0/mail', mail.post);

// PUT Email into
app.put('/api/v0/mail/:id', mail.put);

app.use((err, req, res, next) => {
  res.status(err.status).json({
    message: err.message,
    errors: err.errors,
    status: err.status,
  });
});
export default app;
