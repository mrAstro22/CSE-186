# fs.readdirSync
https://www.geeksforgeeks.org/node-js/node-js-fs-readdirsync-method/

# Persistent Data
https://www.geeksforgeeks.org/node-js/node-js-fs-writefilesync-method/